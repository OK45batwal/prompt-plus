(function () {
  let modalEl = null;
  let selectedTone = "code";

  // Web Platform Session Bridge: Listen for authenticated sessions broadcast by Prompt+ Web Platform
  if (
    location.hostname.includes("prompt-plus-three.vercel.app") ||
    location.hostname.includes("localhost") ||
    location.hostname.includes("prompt-plus")
  ) {
    window.addEventListener("message", (event) => {
      if (event.data && event.data.source === "promptplus_web" && event.data.type === "SESSION_UPDATE") {
        try {
          if (chrome?.runtime?.sendMessage) {
            chrome.runtime.sendMessage({
              action: "saveSessionFromWeb",
              user: event.data.user,
              quota: event.data.quota,
              savedBlocks: event.data.savedBlocks,
            });
          }
        } catch {
          // Ignore background disconnection
        }
      }
    });
  }

  // Fetch initial cached quota
  try {
    if (chrome?.storage?.local) {
      chrome.storage.local.get("pp_web_session", (d) => {
        if (d?.pp_web_session?.quota) {
          userQuota = d.pp_web_session.quota;
        }
      });
    }
  } catch { /* ignore */ }

  function ensureStylesInjected() {
    if (document.getElementById("pp-styles-v2")) return;
    const style = document.createElement("style");
    style.id = "pp-styles-v2";
    style.textContent = `
      .pp-floating-trigger {
        position: fixed !important;
        display: inline-flex !important;
        align-items: center !important;
        gap: 6px !important;
        padding: 5px 12px 5px 8px !important;
        border-radius: 9999px !important;
        background: rgba(14, 14, 18, 0.94) !important;
        border: 1px solid rgba(99, 102, 241, 0.45) !important;
        box-shadow: 0 6px 24px rgba(0, 0, 0, 0.5), 0 0 14px rgba(99, 102, 241, 0.25) !important;
        backdrop-filter: blur(20px) !important;
        -webkit-backdrop-filter: blur(20px) !important;
        font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "Segoe UI", sans-serif !important;
        z-index: 99999999 !important;
        cursor: pointer !important;
        user-select: none !important;
        transition: top 0.12s cubic-bezier(0.16, 1, 0.3, 1), left 0.12s cubic-bezier(0.16, 1, 0.3, 1), transform 0.2s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.2s ease !important;
        color: #ffffff !important;
      }
      .pp-floating-trigger:hover {
        transform: translateY(-2px) scale(1.02) !important;
        border-color: rgba(99, 102, 241, 0.75) !important;
        box-shadow: 0 10px 32px rgba(0, 0, 0, 0.6), 0 0 20px rgba(99, 102, 241, 0.45) !important;
      }
      .pp-floating-trigger:active {
        transform: translateY(0) scale(0.98) !important;
      }

      .pp-trigger-icon {
        width: 20px !important;
        height: 20px !important;
        border-radius: 50% !important;
        background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%) !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-size: 11px !important;
        font-weight: 800 !important;
        color: #ffffff !important;
        box-shadow: inset 0 1px 1px rgba(255, 255, 255, 0.4) !important;
      }

      .pp-trigger-text {
        font-size: 11.5px !important;
        font-weight: 700 !important;
        letter-spacing: -0.01em !important;
        color: #ffffff !important;
        display: flex !important;
        align-items: center !important;
        gap: 5px !important;
      }

      .pp-trigger-token-badge {
        font-size: 9.5px !important;
        font-weight: 600 !important;
        padding: 2px 6px !important;
        border-radius: 9999px !important;
        background: rgba(255, 255, 255, 0.08) !important;
        color: #a1a1aa !important;
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
      }

      /* Floating Modal Studio */
      .pp-floating-modal {
        position: fixed !important;
        z-index: 100000000 !important;
        width: 380px !important;
        max-width: calc(100vw - 32px) !important;
        background: rgba(14, 14, 18, 0.96) !important;
        border: 1px solid rgba(99, 102, 241, 0.45) !important;
        box-shadow: 0 16px 48px rgba(0, 0, 0, 0.7), 0 0 24px rgba(99, 102, 241, 0.25) !important;
        backdrop-filter: blur(24px) !important;
        -webkit-backdrop-filter: blur(24px) !important;
        border-radius: 14px !important;
        padding: 12px 14px !important;
        display: flex !important;
        flex-direction: column !important;
        gap: 10px !important;
        font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "Segoe UI", sans-serif !important;
        color: #f4f4f5 !important;
        user-select: none !important;
        animation: ppModalIn 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
      }

      @keyframes ppModalIn {
        from { opacity: 0; transform: translateY(8px) scale(0.97); }
        to { opacity: 1; transform: translateY(0) scale(1); }
      }

      .pp-modal-header {
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
      }

      .pp-modal-title {
        display: flex !important;
        align-items: center !important;
        gap: 7px !important;
        font-size: 12.5px !important;
        font-weight: 700 !important;
        color: #ffffff !important;
      }

      .pp-modal-close-btn {
        background: transparent !important;
        border: none !important;
        color: #71717a !important;
        font-size: 14px !important;
        cursor: pointer !important;
        padding: 2px 6px !important;
        border-radius: 6px !important;
        transition: color 0.15s ease !important;
      }
      .pp-modal-close-btn:hover {
        color: #ffffff !important;
        background: rgba(255, 255, 255, 0.08) !important;
      }

      .pp-tone-row {
        display: flex !important;
        gap: 4px !important;
        overflow-x: auto !important;
      }

      .pp-tone-chip {
        font-size: 10px !important;
        font-weight: 600 !important;
        padding: 3px 8px !important;
        border-radius: 6px !important;
        background: rgba(255, 255, 255, 0.05) !important;
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
        color: #a1a1aa !important;
        cursor: pointer !important;
        white-space: nowrap !important;
        transition: all 0.15s ease !important;
      }
      .pp-tone-chip:hover {
        color: #ffffff !important;
        background: rgba(255, 255, 255, 0.1) !important;
      }
      .pp-tone-chip.active {
        background: rgba(99, 102, 241, 0.25) !important;
        border-color: rgba(99, 102, 241, 0.6) !important;
        color: #c7d2fe !important;
      }

      .pp-modal-preview {
        background: rgba(0, 0, 0, 0.45) !important;
        border: 1px solid rgba(255, 255, 255, 0.08) !important;
        border-radius: 9px !important;
        padding: 8px 10px !important;
        font-size: 11.5px !important;
        line-height: 1.45 !important;
        color: #e4e4e7 !important;
        max-height: 100px !important;
        overflow-y: auto !important;
        white-space: pre-wrap !important;
        user-select: text !important;
      }

      .pp-modal-actions {
        display: flex !important;
        gap: 6px !important;
      }

      .pp-modal-btn-primary {
        flex: 1 !important;
        height: 36px !important;
        border-radius: 8px !important;
        background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%) !important;
        border: 1px solid rgba(255, 255, 255, 0.15) !important;
        color: #ffffff !important;
        font-size: 11.5px !important;
        font-weight: 700 !important;
        cursor: pointer !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 5px !important;
        box-shadow: 0 4px 14px rgba(99, 102, 241, 0.4) !important;
        transition: all 0.15s ease !important;
      }
      .pp-modal-btn-primary:hover {
        filter: brightness(1.08) !important;
        transform: translateY(-1px) !important;
      }

      .pp-modal-btn-sub {
        height: 36px !important;
        padding: 0 12px !important;
        border-radius: 8px !important;
        background: rgba(255, 255, 255, 0.06) !important;
        border: 1px solid rgba(255, 255, 255, 0.12) !important;
        color: #ffffff !important;
        font-size: 11px !important;
        font-weight: 600 !important;
        cursor: pointer !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 4px !important;
        transition: all 0.15s ease !important;
      }
      .pp-modal-btn-sub:hover {
        background: rgba(255, 255, 255, 0.12) !important;
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  ensureStylesInjected();

  function detectChatbot() {
    const host = location.hostname.toLowerCase();
    if (host.includes("chatgpt") || host.includes("chat.openai") || host.includes("oaistatic")) return "chatgpt";
    if (host.includes("claude.ai") || host.includes("anthropic")) return "claude";
    if (host.includes("gemini.google") || host.includes("bard.google")) return "gemini";
    if (host.includes("aistudio.google")) return "aistudio";
    if (host.includes("deepseek")) return "deepseek";
    if (host.includes("grok") || host.includes("x.ai") || (host.includes("x.com") && location.pathname.includes("grok"))) return "grok";
    if (host.includes("perplexity")) return "perplexity";
    if (host.includes("copilot.microsoft") || (host.includes("bing.com") && location.pathname.includes("chat"))) return "copilot";
    if (host.includes("meta.ai")) return "meta";
    if (host.includes("poe.com")) return "poe";
    if (host.includes("mistral.ai")) return "mistral";
    if (host.includes("huggingface.co/chat")) return "huggingchat";
    if (host.includes("groq.com")) return "groq";
    return "general";
  }

  function isSidebarElement(el) {
    if (!el) return false;
    return Boolean(
      el.closest("aside, nav, [role='navigation'], #sidebar, .sidebar, header, [aria-label*='Search' i], [placeholder*='Search' i], [aria-label*='Notebook' i]")
    );
  }

  function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return (
      style.display !== "none" &&
      style.visibility !== "hidden" &&
      style.opacity !== "0" &&
      rect.width > 0 &&
      rect.height > 0
    );
  }

  function getInput() {
    const bot = detectChatbot();

    // 1. Google Gemini & Google AI Studio
    if (bot === "gemini" || bot === "aistudio") {
      const geminiSelectors = [
        "rich-textarea .ql-editor",
        "rich-textarea div[contenteditable='true']",
        "rich-textarea textarea",
        "input-area-v2 div[contenteditable='true']",
        "div.input-area div[contenteditable='true']",
        "div[aria-label*='Enter a prompt']",
        "div[aria-label*='Ask Gemini']",
        "textarea[aria-label*='prompt']",
        "textarea[placeholder*='Ask Gemini']"
      ];
      for (const s of geminiSelectors) {
        const el = document.querySelector(s);
        if (el && isVisible(el) && !isSidebarElement(el)) return el;
      }
    }

    // 2. ChatGPT (OpenAI)
    if (bot === "chatgpt") {
      const chatgptSelectors = [
        "#prompt-textarea",
        "div[id='prompt-textarea']",
        "div[contenteditable='true']#prompt-textarea",
        "textarea[data-id='root']",
        "textarea#prompt-textarea",
        "textarea[placeholder*='Message ChatGPT']",
        "textarea[placeholder*='Ask anything']"
      ];
      for (const s of chatgptSelectors) {
        const el = document.querySelector(s);
        if (el && isVisible(el) && !isSidebarElement(el)) return el;
      }
    }

    // 3. Claude (Anthropic)
    if (bot === "claude") {
      const claudeSelectors = [
        "div[contenteditable='true'].ProseMirror",
        "fieldset div[contenteditable='true']",
        "div.ProseMirror",
        "div[contenteditable='true'][role='textbox']"
      ];
      for (const s of claudeSelectors) {
        const el = document.querySelector(s);
        if (el && isVisible(el) && !isSidebarElement(el)) return el;
      }
    }

    // 4. DeepSeek
    if (bot === "deepseek") {
      const deepseekSelectors = [
        "textarea#chat-input",
        "textarea[placeholder*='DeepSeek']",
        "div[contenteditable='true']#chat-input",
        "textarea"
      ];
      for (const s of deepseekSelectors) {
        const el = document.querySelector(s);
        if (el && isVisible(el) && !isSidebarElement(el)) return el;
      }
    }

    // 5. Grok (xAI)
    if (bot === "grok") {
      const grokSelectors = [
        "textarea[placeholder*='Ask Grok']",
        "textarea[placeholder*='Grok']",
        "div[contenteditable='true'][data-placeholder*='Grok']",
        "div[contenteditable='true'][role='textbox']",
        "textarea"
      ];
      for (const s of grokSelectors) {
        const el = document.querySelector(s);
        if (el && isVisible(el) && !isSidebarElement(el)) return el;
      }
    }

    // 6. Perplexity AI
    if (bot === "perplexity") {
      const perplexitySelectors = [
        "textarea[placeholder*='Ask anything']",
        "textarea[placeholder*='Ask follow-up']",
        "div[contenteditable='true'][role='textbox']",
        "textarea"
      ];
      for (const s of perplexitySelectors) {
        const el = document.querySelector(s);
        if (el && isVisible(el) && !isSidebarElement(el)) return el;
      }
    }

    // 7. Microsoft Copilot
    if (bot === "copilot") {
      const copilotSelectors = [
        "textarea#userInput",
        "textarea[placeholder*='Message Copilot']",
        "div[contenteditable='true'][role='textbox']",
        "textarea"
      ];
      for (const s of copilotSelectors) {
        const el = document.querySelector(s);
        if (el && isVisible(el) && !isSidebarElement(el)) return el;
      }
    }

    // 8. Meta AI, Poe, Mistral, HuggingChat
    const platformSelectors = [
      "textarea[placeholder*='Ask Meta']",
      "textarea[class*='ChatMessageInput']",
      "textarea[placeholder*='Talk to']",
      "textarea[placeholder*='Ask Le Chat']",
      "textarea[placeholder*='Ask anything']"
    ];
    for (const s of platformSelectors) {
      const el = document.querySelector(s);
      if (el && isVisible(el) && !isSidebarElement(el)) return el;
    }

    // 9. Universal heuristic fallback
    const fallbackSelectors = [
      "form textarea",
      "main div[contenteditable='true']",
      "main textarea",
      "div[contenteditable='true'][role='textbox']",
      "div[contenteditable='true']",
      "textarea[placeholder*='Message']",
      "textarea[placeholder*='Ask']",
      "textarea[placeholder*='prompt']",
      "textarea[placeholder*='chat']",
      "textarea"
    ];
    for (const s of fallbackSelectors) {
      const el = document.querySelector(s);
      if (el && isVisible(el) && !isSidebarElement(el)) return el;
    }
    return null;
  }

  function getText(el) {
    if (!el) return "";
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      return el.value || "";
    }
    if (el.isContentEditable) {
      return el.innerText || el.textContent || "";
    }
    return "";
  }

  function setText(el, val) {
    if (!el) return;
    el.focus();

    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      el.value = val;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    } else if (el.isContentEditable) {
      try {
        // Multi-strategy rich-text injection (Quill, ProseMirror, Slate, Lexical)
        document.execCommand("selectAll", false, null);
        const success = document.execCommand("insertText", false, val);
        if (!success || !el.innerText || !el.innerText.trim()) {
          el.innerHTML = "";
          const p = document.createElement("p");
          p.innerText = val;
          el.appendChild(p);
        }
      } catch {
        el.innerHTML = "";
        const p = document.createElement("p");
        p.innerText = val;
        el.appendChild(p);
      }
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: val }));
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }

  function getChatContainer(input) {
    let parent = input.parentElement;
    for (let i = 0; i < 6 && parent; i++) {
      const style = window.getComputedStyle(parent);
      if (
        (parent.tagName === "FORM" ||
          parent.classList.contains("relative") ||
          parent.classList.contains("input-area") ||
          parent.classList.contains("input-area-v2") ||
          style.position === "relative" ||
          style.position === "sticky") &&
        parent.offsetWidth > 280
      ) {
        return parent;
      }
      parent = parent.parentElement;
    }
    return input;
  }

  function showToast(msg) {
    const t = document.createElement("div");
    t.textContent = msg;
    Object.assign(t.style, {
      position: "fixed", bottom: "24px", left: "50%", transform: "translateX(-50%)",
      background: "rgba(10,10,12,0.92)", color: "#f1f5f9", padding: "8px 18px", borderRadius: "12px",
      fontSize: "12px", fontWeight: "600", zIndex: "100000001", boxShadow: "0 8px 32px rgba(0,0,0,0.5)",
      border: "1px solid rgba(255,255,255,0.12)", backdropFilter: "blur(12px)", transition: "all 0.3s ease"
    });
    document.body.appendChild(t);
    setTimeout(() => {
      t.style.opacity = "0";
      t.style.transform = "translate(-50%, 10px)";
      setTimeout(() => t.remove(), 300);
    }, 2800);
  }

  function synthesizeLocalPrompt(userInput, tone = "code") {
    const text = (userInput || "").trim();
    if (!text) return "";
    const cleanInput = text.replace(/^(please|can you|help me|i want to|i need to|how to|write|create|build|fix|generate|make)\s+/i, "");
    const subject = cleanInput.length > 0 ? cleanInput : text;
    const bot = detectChatbot();

    let role = "Senior Subject Matter Expert & Principal Architect";
    let toneStr = "Technically Rigorous, Production-Grade";
    let sec1 = "SPECIFICATIONS & ARCHITECTURAL CONSTRAINTS";
    let sec2 = "IMPLEMENTATION PROTOCOL";
    let antiCliche = "- **STRICT ANTI-CLICHÉ PROTOCOL**: Never use robotic AI buzzwords ('delve into', 'tapestry', 'testament', 'in conclusion', 'as an AI', 'game changer', 'unleash', 'seamlessly').";

    if (tone === "human") {
      role = "Experienced Senior Peer & Pragmatic Thought Partner";
      toneStr = "Authentic, Human-Sounding, Natural Cadence & Zero Fluff";
      sec1 = "CORE GOAL & AUTHENTIC HUMAN CONTEXT";
      sec2 = "PRAGMATIC EXECUTION STEPS";
      antiCliche = "- **STRICT HUMAN VOICE MANDATE**: Write naturally like an experienced human peer. Vary sentence length for organic rhythm. Eliminate preamble ('Certainly! Here is...') and concluding summaries. Explicitly avoid all AI buzzwords and corporate fluff.";
    } else if (tone === "copy") {
      role = "Elite Conversion Copywriter & Brand Strategist";
      toneStr = "High-Conversion, Punchy & Action-Oriented";
      sec1 = "AUDIENCE HOOK & VALUE DIRECTIVES";
      sec2 = "NARRATIVE EXECUTION STEPS";
    } else if (tone === "exec") {
      role = "Senior Management Consultant & Executive Director";
      toneStr = "Concise, Strategic & Metric-Driven";
      sec1 = "STRATEGIC OBJECTIVES & CONSTRAINTS";
      sec2 = "ACTIONABLE ROADMAP & DECISION STEPS";
    } else if (tone === "deep") {
      role = "Lead AI Research Scientist & Deep Logic Reasoner";
      toneStr = "Exhaustive, First-Principles Reasoning";
      sec1 = "CORE HYPOTHESES & LOGICAL CONSTRAINTS";
      sec2 = "STEP-BY-STEP DEDUCTION & VALIDATION";
    }

    if (bot === "claude") {
      return `<role_and_objective>
  <persona>${role}</persona>
  <task>${text}</task>
</role_and_objective>

<specifications>
  <subject>${subject}</subject>
  <tone_profile>${toneStr}</tone_profile>
  <anti_cliche_mandate>${antiCliche.replace("- **STRICT ANTI-CLICHÉ PROTOCOL**: ", "").replace("- **STRICT HUMAN VOICE MANDATE**: ", "")}</anti_cliche_mandate>
</specifications>

<execution_steps>
  <step>1. Analyze objective from first principles.</step>
  <step>2. Provide direct, production-grade output formatted cleanly without meta commentary.</step>
</execution_steps>`;
    }

    return `### ROLE & PERSONA
You are an authoritative ${role}. Execute this task with highest precision:
"${text}"

### ${sec1}
- **Subject**: "${subject}"
- **Tone Profile**: ${toneStr}
${antiCliche}
- **Quality Constraint**: Deliver complete, immediately usable results without placeholders or conversational fluff.

### ${sec2}
1. Analyze core requirements for "${subject}" and anticipate implicit edge cases.
2. Structure output with modular sections, scannable Markdown headers, and concrete code/examples.
3. Validate solution against real-world usability, scalability, and performance.

### DELIVERABLES & OUTPUT FORMAT
- Deliver complete, immediately usable results formatted in clean Markdown.`;
  }

  function getModelContextInfo() {
    const bot = detectChatbot();
    if (bot === "gemini") {
      return { botKey: "GEMINI", name: "Gemini 2.0 / 1.5", maxContext: 1000000, tag: "1,000K Context", color: "#3b82f6" };
    }
    if (bot === "aistudio") {
      return { botKey: "AISTUDIO", name: "Google AI Studio", maxContext: 2000000, tag: "2,000K Context", color: "#4285f4" };
    }
    if (bot === "claude") {
      return { botKey: "CLAUDE", name: "Claude 3.5 Sonnet", maxContext: 200000, tag: "200K Context", color: "#d97706" };
    }
    if (bot === "chatgpt") {
      return { botKey: "CHATGPT", name: "ChatGPT (GPT-4o)", maxContext: 128000, tag: "128K Context", color: "#10a37f" };
    }
    if (bot === "deepseek") {
      return { botKey: "DEEPSEEK", name: "DeepSeek R1", maxContext: 128000, tag: "128K Context", color: "#6366f1" };
    }
    if (bot === "grok") {
      return { botKey: "GROK", name: "Grok 3 (xAI)", maxContext: 128000, tag: "128K Context", color: "#ec4899" };
    }
    if (bot === "perplexity") {
      return { botKey: "PERPLEXITY", name: "Perplexity AI", maxContext: 32000, tag: "32K Context", color: "#20b2aa" };
    }
    if (bot === "copilot") {
      return { botKey: "COPILOT", name: "Microsoft Copilot", maxContext: 128000, tag: "128K Context", color: "#0078d4" };
    }
    if (bot === "meta") {
      return { botKey: "META", name: "Meta Llama 3", maxContext: 128000, tag: "128K Context", color: "#0668e1" };
    }
    if (bot === "mistral") {
      return { botKey: "MISTRAL", name: "Mistral Le Chat", maxContext: 128000, tag: "128K Context", color: "#ea580c" };
    }
    if (bot === "poe") {
      return { botKey: "POE", name: "Poe AI", maxContext: 128000, tag: "128K Context", color: "#8b5cf6" };
    }
    if (bot === "huggingchat") {
      return { botKey: "HUGGINGCHAT", name: "HuggingChat", maxContext: 32000, tag: "32K Context", color: "#f59e0b" };
    }
    return { botKey: "AI", name: "Universal Chatbot", maxContext: 128000, tag: "128K Context", color: "#6366f1" };
  }

  // Open Floating Optimizer Modal
  function openFloatingModal(inputEl) {
    if (modalEl) {
      modalEl.remove();
      modalEl = null;
    }

    const currentVal = getText(inputEl).trim();
    const tokenCount = Math.ceil(currentVal.length / 3.8);
    const modelInfo = getModelContextInfo();
    const freeTokens = Math.max(0, modelInfo.maxContext - tokenCount);
    const freeK = (freeTokens / 1000).toFixed(1);
    const usedPct = Math.min(100, Math.max(1, (tokenCount / modelInfo.maxContext) * 100)).toFixed(2);
    const freePct = (100 - parseFloat(usedPct)).toFixed(1);

    modalEl = document.createElement("div");
    modalEl.className = "pp-floating-modal";

    modalEl.innerHTML = `
      <div class="pp-modal-header">
        <div class="pp-modal-title">
          <span style="color:#6366f1;font-size:14px;">✦</span>
          <span>Prompt+ Instant Optimizer</span>
          <span style="font-size:9.5px;color:${modelInfo.color};font-weight:800;padding:1px 6px;border-radius:4px;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);">🟢 ${modelInfo.name}</span>
        </div>
        <button type="button" class="pp-modal-close-btn" id="pp-modal-close">✕</button>
      </div>

      <!-- Real-Time Token Context Remaining Telemetry Card -->
      <div style="background:rgba(0,0,0,0.45);border:1px solid rgba(255,255,255,0.08);border-radius:9px;padding:7px 10px;display:flex;flex-direction:column;gap:4px;">
        <div style="display:flex;align-items:center;justify-content:space-between;font-size:10.5px;">
          <span style="font-weight:700;color:#ffffff;">Remaining Context</span>
          <span style="font-weight:800;color:#10b981;background:rgba(16,185,129,0.15);padding:1px 6px;border-radius:4px;border:1px solid rgba(16,185,129,0.3);">${freeK}K tokens free (${freePct}%)</span>
        </div>
        <div style="width:100%;height:4.5px;border-radius:9999px;background:rgba(255,255,255,0.1);overflow:hidden;">
          <div style="height:100%;border-radius:9999px;background:linear-gradient(90deg,#6366f1 0%,#10b981 100%);width:${Math.max(8, freePct)}%;box-shadow:0 0 8px rgba(16,185,129,0.4);"></div>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;font-size:9.5px;color:#a1a1aa;">
          <span>Prompt Load: ~${tokenCount} tokens</span>
          <span>Max Window: ${(modelInfo.maxContext / 1000).toFixed(0)}K tokens</span>
        </div>
      </div>

      <div class="pp-tone-row">
        <div class="pp-tone-chip ${selectedTone === "human" ? "active" : ""}" data-tone="human">🗣️ Human Voice</div>
        <div class="pp-tone-chip ${selectedTone === "code" ? "active" : ""}" data-tone="code">💻 Tech</div>
        <div class="pp-tone-chip ${selectedTone === "copy" ? "active" : ""}" data-tone="copy">📈 Copy</div>
        <div class="pp-tone-chip ${selectedTone === "exec" ? "active" : ""}" data-tone="exec">👔 Executive</div>
        <div class="pp-tone-chip ${selectedTone === "deep" ? "active" : ""}" data-tone="deep">🔬 Deep Logic</div>
      </div>

      <div class="pp-modal-preview" id="pp-modal-preview">
        ${currentVal || "Type your prompt idea in the chatbox below..."}
      </div>

      <div class="pp-modal-actions">
        <button type="button" class="pp-modal-btn-primary" id="pp-modal-replace-btn">
          <span>⚡ Optimize & Replace in Chat</span>
        </button>
        <button type="button" class="pp-modal-btn-sub" id="pp-modal-copy-btn" title="Copy to clipboard">
          <span>📋</span>
        </button>
      </div>
    `;

    document.body.appendChild(modalEl);

    // Position modal right above the input box
    const card = getChatContainer(inputEl) || inputEl;
    const rect = card.getBoundingClientRect();
    const modalHeight = modalEl.offsetHeight || 260;
    const modalWidth = modalEl.offsetWidth || 380;

    let top = rect.top - modalHeight - 12;
    if (top < 12) top = rect.top + 8;
    let left = rect.right - modalWidth;
    if (left < 16) left = 16;

    modalEl.style.top = `${Math.round(top)}px`;
    modalEl.style.left = `${Math.round(left)}px`;

    // Event handlers with stopPropagation to prevent host page cancellation
    modalEl.querySelector("#pp-modal-close")?.addEventListener("click", (e) => {
      e.stopPropagation();
      modalEl.remove();
      modalEl = null;
    });

    modalEl.querySelectorAll(".pp-tone-chip").forEach((chip) => {
      chip.addEventListener("click", (e) => {
        e.stopPropagation();
        modalEl.querySelectorAll(".pp-tone-chip").forEach((c) => c.classList.remove("active"));
        chip.classList.add("active");
        selectedTone = chip.getAttribute("data-tone") || "code";
      });
    });

    modalEl.querySelector("#pp-modal-replace-btn")?.addEventListener("click", (e) => {
      e.stopPropagation();
      const raw = getText(inputEl).trim();
      if (!raw) {
        showToast("⚠️ Type your prompt idea in the chat box first!");
        return;
      }
      const masterPrompt = synthesizeLocalPrompt(raw, selectedTone);
      setText(inputEl, masterPrompt);
      showToast("✓ Master prompt compiled & replaced in chat!");
      modalEl.remove();
      modalEl = null;
    });

    modalEl.querySelector("#pp-modal-copy-btn")?.addEventListener("click", (e) => {
      e.stopPropagation();
      const raw = getText(inputEl).trim();
      const masterPrompt = synthesizeLocalPrompt(raw || "Build full stack scalable app", selectedTone);
      navigator.clipboard.writeText(masterPrompt);
      showToast("✓ Copied Master Prompt!");
    });
  }

  function resolveChatCapsule(input) {
    if (!input) return null;
    let cur = input.parentElement;
    let best = input;
    for (let i = 0; i < 8 && cur && cur !== document.body; i++) {
      const tag = cur.tagName.toLowerCase();
      const cls = (cur.className || "").toString().toLowerCase();
      if (
        tag === "input-area-v2" ||
        tag === "form" ||
        tag === "fieldset" ||
        cls.includes("input-area") ||
        cls.includes("chat-input") ||
        cls.includes("composer-parent") ||
        cls.includes("text-input-field") ||
        cls.includes("conversation-compose") ||
        cls.includes("prosemirror-focused") ||
        cls.includes("bottom-composer") ||
        cls.includes("chat-composer") ||
        cur.getAttribute("role") === "region" ||
        cur.offsetWidth > 380
      ) {
        best = cur;
      }
      cur = cur.parentElement;
    }
    return best;
  }

  // Inject sleek floating trigger button
  function injectFloatingButton() {
    if (!document.body) return;
    ensureStylesInjected();

    const existing = document.querySelector(".pp-floating-trigger");
    if (existing) {
      if (document.body.contains(existing._targetInput) && isVisible(existing._targetInput)) {
        positionFloatingButton(existing, existing._targetInput);
        return;
      }
      try { existing.remove(); } catch { /* ignore */ }
    }

    const input = getInput();
    if (!input || !input.parentElement) return;

    const rect = input.getBoundingClientRect();
    if (!rect || rect.width === 0) { setTimeout(injectFloatingButton, 800); return; }

    const trigger = document.createElement("div");
    trigger.className = "pp-floating-trigger";
    trigger._targetInput = input;

    const model = getModelContextInfo();
    const initialVal = getText(input).trim();
    const initialTokens = initialVal.length > 0 ? Math.ceil(initialVal.length / 3.8) : 0;
    const initialFreeK = Math.max(0, (model.maxContext - initialTokens) / 1000).toFixed(0);
    const badgeLabel = initialTokens > 0 ? `${initialFreeK}K free · ~${initialTokens} tok` : `${initialFreeK}K free`;

    trigger.innerHTML = `
      <div class="pp-trigger-icon">✦</div>
      <div class="pp-trigger-text">
        <span>Enhance</span>
        <span class="pp-trigger-token-badge" id="pp-trigger-tok">${badgeLabel}</span>
      </div>
    `;

    document.body.appendChild(trigger);
    positionFloatingButton(trigger, input);

    // Live typing token count
    const updateTokens = () => {
      const val = getText(input).trim();
      const tokens = val.length > 0 ? Math.ceil(val.length / 3.8) : 0;
      const m = getModelContextInfo();
      const freeK = Math.max(0, (m.maxContext - tokens) / 1000).toFixed(0);
      const tokBadge = trigger.querySelector("#pp-trigger-tok");
      if (tokBadge) {
        tokBadge.textContent = tokens > 0 ? `${freeK}K free · ~${tokens} tok` : `${freeK}K free`;
      }
    };
    input.addEventListener("input", updateTokens);
    updateTokens();

    setupDraggable(trigger);

    // Reliable click handler
    trigger.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (trigger._hasMoved && trigger._hasMoved()) return;
      openFloatingModal(input);
    });

    let rafPending = false;
    const schedulePosition = () => {
      if (rafPending) return;
      rafPending = true;
      requestAnimationFrame(() => {
        rafPending = false;
        if (document.body.contains(trigger) && document.body.contains(input)) {
          positionFloatingButton(trigger, input);
        }
      });
    };

    // Dynamic Text Field Observers: Follows the chatbot input as it grows, shrinks, or moves
    input.addEventListener("input", schedulePosition);
    input.addEventListener("focus", schedulePosition);
    input.addEventListener("blur", schedulePosition);
    input.addEventListener("keyup", schedulePosition);

    const capsule = resolveChatCapsule(input) || input;

    try {
      if (window.ResizeObserver) {
        const ro = new ResizeObserver(() => schedulePosition());
        ro.observe(input);
        if (capsule && capsule !== input) ro.observe(capsule);
      }
    } catch {}

    window.addEventListener("scroll", schedulePosition, { passive: true });
    window.addEventListener("resize", schedulePosition, { passive: true });
  }

  function positionFloatingButton(trigger, input) {
    if (!input || !trigger) return;
    if (!document.body.contains(input) || isSidebarElement(input)) {
      trigger.style.setProperty("display", "none", "important");
      return;
    }

    // Check if user has saved a custom dragged position
    const customPosStr = localStorage.getItem("pp_btn_custom_pos");
    if (customPosStr) {
      try {
        const pos = JSON.parse(customPosStr);
        if (typeof pos.top === "number" && typeof pos.left === "number") {
          const clampedTop = Math.max(8, Math.min(window.innerHeight - 40, pos.top));
          const clampedLeft = Math.max(8, Math.min(window.innerWidth - 140, pos.left));
          trigger.style.setProperty("top", `${clampedTop}px`, "important");
          trigger.style.setProperty("left", `${clampedLeft}px`, "important");
          trigger.style.setProperty("display", "inline-flex", "important");
          return;
        }
      } catch {}
    }

    // Find the full outermost active prompt capsule
    const capsule = resolveChatCapsule(input) || input;
    const rect = capsule.getBoundingClientRect();
    if (!rect || rect.width === 0 || rect.height === 0 || rect.top < 0) {
      trigger.style.setProperty("display", "none", "important");
      return;
    }

    const triggerHeight = trigger.offsetHeight || 32;
    const triggerWidth = trigger.offsetWidth || 155;
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;

    // Ergonometric vertical placement with clean 14px separation
    let top = 0;
    if (rect.bottom + triggerHeight + 20 < viewportHeight) {
      top = rect.bottom + 14;
    } else {
      top = rect.top - triggerHeight - 14;
    }

    if (top < 10) top = 10;
    if (top + triggerHeight > viewportHeight - 10) top = viewportHeight - triggerHeight - 10;

    // Align right with outer chat capsule
    let left = rect.right - triggerWidth - 6;
    if (left < 16) left = 16;
    if (left + triggerWidth > viewportWidth - 16) {
      left = Math.max(16, viewportWidth - triggerWidth - 16);
    }

    trigger.style.setProperty("top", `${Math.round(top)}px`, "important");
    trigger.style.setProperty("left", `${Math.round(left)}px`, "important");
    trigger.style.setProperty("display", "inline-flex", "important");
  }

  // Draggable support for floating button
  function setupDraggable(trigger) {
    let isDragging = false;
    let startX = 0;
    let startY = 0;
    let initialLeft = 0;
    let initialTop = 0;
    let moved = false;

    trigger.addEventListener("mousedown", (e) => {
      if (e.button !== 0) return;
      isDragging = true;
      moved = false;
      startX = e.clientX;
      startY = e.clientY;
      const rect = trigger.getBoundingClientRect();
      initialLeft = rect.left;
      initialTop = rect.top;
      trigger.style.transition = "none";
    });

    document.addEventListener("mousemove", (e) => {
      if (!isDragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
        moved = true;
      }
      const newLeft = Math.max(8, Math.min(window.innerWidth - trigger.offsetWidth - 8, initialLeft + dx));
      const newTop = Math.max(8, Math.min(window.innerHeight - trigger.offsetHeight - 8, initialTop + dy));
      trigger.style.setProperty("left", `${newLeft}px`, "important");
      trigger.style.setProperty("top", `${newTop}px`, "important");
    });

    document.addEventListener("mouseup", () => {
      if (!isDragging) return;
      isDragging = false;
      trigger.style.transition = "";
      if (moved) {
        const rect = trigger.getBoundingClientRect();
        localStorage.setItem("pp_btn_custom_pos", JSON.stringify({ top: rect.top, left: rect.left }));
      }
    });

    // Double click resets position to default anchor
    trigger.addEventListener("dblclick", (e) => {
      e.preventDefault();
      e.stopPropagation();
      localStorage.removeItem("pp_btn_custom_pos");
      showToast("✓ Button position reset to default");
      if (trigger._targetInput) {
        positionFloatingButton(trigger, trigger._targetInput);
      }
    });

    trigger._hasMoved = () => moved;
  }

  // Keyboard shortcut listener: Cmd+Shift+P / Ctrl+Shift+P to enhance in-place
  document.addEventListener("keydown", (e) => {
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && (e.key === "P" || e.key === "p")) {
      e.preventDefault();
      const input = getInput();
      if (input) {
        const text = getText(input);
        if (text && text.trim()) {
          showToast("⚡ Compiling master prompt in-place...");
          const master = synthesizeLocalPrompt(text, selectedTone);
          setText(input, master);
          showToast("✓ Prompt optimized in-place!");
        } else {
          openFloatingModal(input);
        }
      }
    }
  });

  // Observe DOM changes to re-inject when new chat views render
  setInterval(() => {
    const input = getInput();
    if (input && !document.querySelector(".pp-floating-trigger")) {
      injectFloatingButton();
    }
  }, 1000);

  window.addEventListener("focus", () => {
    const input = getInput();
    if (input) injectFloatingButton();
  });
})();
